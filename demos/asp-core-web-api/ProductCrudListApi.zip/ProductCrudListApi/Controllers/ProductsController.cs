using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("[controller]")]
public class ProductsController:ControllerBase{

    private static List<Product> products=new List<Product>(){
        new Product{Id=1,Name="pen",Price=25},
        new Product{Id=2,Name="pencil",Price=5}
        };

[HttpGet]
public List<Product> GetProducts(){
return products;
}
[HttpPost]
public void Create(Product product){
    products.Add(product);
}

}